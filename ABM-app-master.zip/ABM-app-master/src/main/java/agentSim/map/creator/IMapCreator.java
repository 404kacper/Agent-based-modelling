package agentSim.map.creator;

import agentSim.map.IMap;

public interface IMapCreator {
    public IMap createMap();
}
