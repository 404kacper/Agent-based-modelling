package agentSim.agentCreator;

public interface IAgentCreator {
}
