package agentSim.agentCreator;

public class AgentCreator implements IAgentCreator{
}
