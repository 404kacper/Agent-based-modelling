package agentSim.agent.animal;

public class Animal {
}
