package agentSim.agent;

public class Agent implements IAgent{
}
