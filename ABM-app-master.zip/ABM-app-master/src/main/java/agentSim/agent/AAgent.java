package agentSim.agent;

public abstract class AAgent {
}
