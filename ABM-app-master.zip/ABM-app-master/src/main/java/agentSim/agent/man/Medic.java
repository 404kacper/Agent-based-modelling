package agentSim.agent.man;

public class Medic {
}
