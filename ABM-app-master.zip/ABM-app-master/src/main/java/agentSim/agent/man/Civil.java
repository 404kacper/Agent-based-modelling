package agentSim.agent.man;

public class Civil {
}
