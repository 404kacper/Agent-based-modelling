package agentSim.agent.man;

public class Man {
}
